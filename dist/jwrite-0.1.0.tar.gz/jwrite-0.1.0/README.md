# jwrite

## About -

This is a minimal notepad clone made to learn [PySide6](https://doc.qt.io/qtforpython/index.html) for a school project. It uses QUI files for structuring its main components.